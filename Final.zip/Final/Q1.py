import functools

def trc1(g):
    @functools.wraps(g)
    def wrapr(*args, **kwargs):
        print(f"Calling {hex(id(g))} on argument {args[0]}")
        return g(*args, **kwargs)
    return wrapr

@trc1
def square(x):
    return x * x

@trc1
def sum_square(n):
    result = 0
    for i in range(1, n + 1):
        result += square(i)
    return result

def main():
    try:
        value = eval(input("Enter a value: "))
        print(square(value))
        print(sum_square(value))
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
