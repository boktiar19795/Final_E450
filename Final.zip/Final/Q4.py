class Fibonacci:
    def __init__(self):
        self.val = 0
        self.nxt_number = 1
    def nxt(self):
        answer = Fibonacci()
        answer.val = self.nxt_number
        answer.nxt_number = self.val + self.nxt_number
        return answer
    def __repr__(self):
        return str(self.val)
a = Fibonacci()
print(a)
print(a.nxt())
print(a.nxt().nxt())
print(a.nxt().nxt().nxt())
print(a.nxt().nxt().nxt().nxt())
print(a.nxt().nxt().nxt().nxt().nxt())
print(a.nxt().nxt().nxt().nxt().nxt().nxt())