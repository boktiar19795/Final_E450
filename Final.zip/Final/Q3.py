def deep_rvrs(tup):
    return tuple(deep_rvrs(m) if isinstance(m, tuple)
else m
               for m in reversed(tup))
a = (11, 12, 13, 14)
print(deep_rvrs(a))
tple = (15, (12, (13, 113), 14), 15)
print(deep_rvrs(tple))